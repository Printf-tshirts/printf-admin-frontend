export const LOCAL_BACKEND_URL = "http://localhost:5000/api";
